//
//  galeriasVC.m
//  Alltech
//
//  Created by Tejuino developers on 09/02/15.
//  Copyright (c) 2015 Tejuino developers. All rights reserved.
//

#import "galeriasVC.h"
#import "SWRevealViewController.h"
#import "CSAnimationView.h"

@interface galeriasVC ()

@end

@implementation galeriasVC{

    CGRect screenBound;
    CGSize screenSize;
    CGFloat screenWidth;
    CGFloat screenHeight;
    
    CGFloat porcentaje;
    CGFloat resultadoPorcentaje;


}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Inicializamos las variables para recoger las dimensiones de la pantalla
    
    screenBound = [[UIScreen mainScreen] bounds];
    screenSize = screenBound.size;
    screenWidth = screenSize.width;
    screenHeight = screenSize.height;
    porcentaje = 25;
    
    resultadoPorcentaje = (porcentaje * screenWidth) / 100;
    
    
    //Cambiar Color del Background del View.
    self.view.backgroundColor = [UIColor orangeColor];
    
    //Quitar la sobra de la barra de navegacion
    [self.galeriasNav setBackgroundImage:[[UIImage alloc] init]
                                                  forBarMetrics:UIBarMetricsDefault];
    self.galeriasNav.shadowImage = [[UIImage alloc] init];
    
    

    
    //Slide-out right Menu
    
    SWRevealViewController * revealViewController = self.revealViewController;
    if (revealViewController) {
        
        
        [self.rightMenu setTarget: self.revealViewController];
        [self.rightMenu setAction: @selector( rightRevealToggle:)];
        revealViewController.rightViewRevealWidth= resultadoPorcentaje;
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    
    
    // Return the number of sections.
    
    return 1;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{


    return 3;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    tableView = _galeriasTable;

    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
        
    }
    
    
    
    // cambiamos el color de la celda a transparente
    cell.backgroundColor = [UIColor clearColor];
    
    
    
    //depende de la celda personalizamos contenido
    NSLog(@"este es el indice: %li",(long)indexPath.row);
   
    
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

//    slideShowVC * destinationController = [[slideShowVC alloc]init];
//    //self.modalPresentationStyle = UIModalPresentationCurrentContext;
//    [self presentViewController:destinationController animated:YES completion:nil];



}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//Cambiamos a blanco el color de la status Bar

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}



- (IBAction)returnButton:(id)sender {
    
    [self.navigationController popViewControllerAnimated:TRUE];
    
}
@end






#pragma mark -



@interface slideShowVC ()

@property (nonatomic, strong) NSMutableArray *items;
@property (strong, nonatomic) UIImageView *zoomImage;

-(void)handlePinchWithGestureRecognizer:(UIPinchGestureRecognizer *)pinchGestureRecognizer;

@end




@implementation slideShowVC{

    NSArray * fotosAlbum;
    NSArray * descripcionFoto;
    CGRect screenBound;
    CGSize screenSize;
    CGFloat screenWidth;
    CGFloat screenHeight;

}

@synthesize customCarousel;
@synthesize items;




- (void)awakeFromNib
{
    //set up data
    //your carousel should always be driven by an array of
    //data of some kind - don't store data in your item views
    //or the recycling mechanism will destroy your data once
    //your item views move off-screen
    self.items = [NSMutableArray array];
    for (int i = 0; i < 7; i++)
    {
        [items addObject:@(i)];
    }
    
    fotosAlbum =[NSArray arrayWithObjects:@"ejemplo1.png",@"ejemplo2.png",@"ejemplo3.png",@"ejemplo4.png",@"ejemplo5.png",@"ejemplo6.png",@"ejemplo7.png", nil];
    descripcionFoto=[NSArray arrayWithObjects:@"asd",@"ghf",@"rt",@"cvb",@"kj",@"asuid",@"xc", nil];
    
}



- (void)dealloc
{
    //it's a good idea to set these to nil here to avoid
    //sending messages to a deallocated viewcontroller
    customCarousel.delegate = nil;
    customCarousel.dataSource = nil;
    _scroller.delegate=self;
}


-(void)viewDidLoad{
    
    
    //Inicializamos las variables para recoger las dimensiones de la pantalla
    
    screenBound = [[UIScreen mainScreen] bounds];
    screenSize = screenBound.size;
    screenWidth = screenSize.width;
    screenHeight = screenSize.height;
    
    
    //definimos el tipo de carrusel
    
    customCarousel.type = iCarouselTypeLinear;
    
    
//    CGSize offset = CGSizeMake(0.0f,25.0f);
//    customCarousel.viewpointOffset = offset;
    customCarousel.scrollSpeed = 0.5;
    
    
    self.zoomImage = [[UIImageView alloc]initWithFrame:CGRectMake(40, 170, 300, 280)];
    [self.view addSubview:self.zoomImage];
    self.zoomImage.hidden = YES;



    // Metodos para el reconocimiento de gesto (derecha e izquierda)
//    
//    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe:)];
//    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
//    [self.view addGestureRecognizer:swipeLeft];
//    
//    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipe:)];
//    swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
//    [self.view addGestureRecognizer:swipeRight];
    

}

-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
    return self.zoomImage;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    //free up memory by releasing subviews
    self.customCarousel = nil;
    
}

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    //return the total number of items in the carousel
    return [fotosAlbum  count];
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    UILabel *label = nil;
    //create new view if no view is available for recycling
    if (view == nil)
    {
        
        //NSLog(@"Estas son las cordenadas del view iCarousel con bounds:  X:%f, Y:%f",self.carousel.bounds.origin.x,self.carousel.bounds.origin.y);
        //NSLog(@"Estas son las cordenadas del view iCarousel con frame:  width:%f, heigth:%f",self.carousel.frame.origin.x,self.carousel.frame.origin.y);
        //view = [[UIImageView alloc] initWithFrame:CGRectMake(0,0, 300.0f, 280.0f)];
        view = [[UIImageView alloc] initWithFrame:CGRectMake(customCarousel.frame.origin.x+20, customCarousel.frame.origin.y, customCarousel.frame.size.width-100, customCarousel.frame.size.height)];
        ((UIImageView *)view).image = [UIImage imageNamed:@"fondo"];
        view.contentMode = UIViewContentModeScaleAspectFit;
        label = [[UILabel alloc] initWithFrame:view.bounds];
        label.backgroundColor = [UIColor clearColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [label.font fontWithSize:50];
        label.tag = 1;
        //[view addSubview:label];
        //[view addSubview:image];
        NSLog(@"texto descripcion: %li",(long)index);
    }
    else
    {
        //get a reference to the label in the recycled view
        label = (UILabel *)[view viewWithTag:1];
    }
    
    //set item label
    //remember to always set any properties of your carousel item
    //views outside of the `if (view == nil) {...}` check otherwise
    //you'll get weird issues with carousel item content appearing
    //in the wrong place in the carousel
    //label.text = [items[index] stringValue];
    
    //For showing images
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
        dispatch_async(dispatch_get_main_queue(), ^{
            ((UIImageView *)view).image = [UIImage imageNamed:[fotosAlbum objectAtIndex:index]];
            self.zoomImage.image = [UIImage imageNamed:[fotosAlbum objectAtIndex:index]];
        });
    });
    
//    self.zoomImage = [[UIImageView alloc]initWithFrame:view.frame];
//    [view addSubview:self.zoomImage];
//    self.zoomImage.hidden = YES;
    
    UITapGestureRecognizer *doubleTap =[[UITapGestureRecognizer alloc] initWithTarget: self action:@selector(doDoubleTap:)];
    doubleTap.numberOfTapsRequired = 2;
    [customCarousel addGestureRecognizer:doubleTap];
    
    UIPinchGestureRecognizer *pinchGestureRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinchWithGestureRecognizer:)];
    [customCarousel addGestureRecognizer:pinchGestureRecognizer];
    
    
    
    return view;
}



-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{

        self.zoomImage.image = [UIImage imageNamed:[fotosAlbum objectAtIndex:index]];
    
    

}

-(void)carouselWillBeginScrollingAnimation:(iCarousel *)carousel{

    self.zoomImage.hidden=YES;
    
}

-(void)handlePinchWithGestureRecognizer:(UIPinchGestureRecognizer *)pinchGestureRecognizer{
    
    NSLog(@"por fin reconocio que se dio el gesto Pinch");
    self.zoomImage.hidden=NO;
    self.zoomImage.contentMode = UIViewContentModeScaleAspectFit;
    self.zoomImage.transform = CGAffineTransformScale(self.zoomImage.transform, pinchGestureRecognizer.scale, pinchGestureRecognizer.scale);
    pinchGestureRecognizer.scale = 1.0;
    
}



-(void)doDoubleTap:(UITapGestureRecognizer *)selector{


    NSLog(@"por fin reconocio que se dio un doble tap");
    
    self.zoomImage.hidden = NO;
    self.zoomImage.contentMode = UIViewContentModeScaleAspectFit;
    [UIView transitionWithView:self.view duration:2.0 options:UIViewAnimationOptionTransitionNone animations:^{
        [self.zoomImage setFrame:CGRectMake(0, 0, screenWidth, screenHeight-20)];
        
    }completion:nil];
    
    


}

//- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value;{
//    option = iCarouselOptionSpacing;
//    return 1.5;
//}


//- (void)swipe:(UISwipeGestureRecognizer *)swipeRecogniser
//{
//    if ([swipeRecogniser direction] == UISwipeGestureRecognizerDirectionLeft)
//    {
//        self.pager.currentPage +=1;
//        
//        if (self.pager.currentPage == 1) {
//       
//            // Start
//            _picImageView.transform = CGAffineTransformMakeScale(1.5, 1.5);
//            _picImageView.alpha = 0;
//            [UIView animateKeyframesWithDuration:0.4 delay:0 options:0 animations:^{
//                // End
//                _picImageView.transform = CGAffineTransformMakeScale(1, 1);
//                _picImageView.alpha = 1;
//            } completion:^(BOOL finished) {
//            }];
//            
//        }
//                
//        
//        
////        self.picImageView.alpha = 0;
////        [UIImageView animateKeyframesWithDuration:0.5 delay:0 options:0 animations:^{
////            
////            self.picImageView.alpha = 1;
////        } completion:^(BOOL finished) { }];
//        
//        
//        
//        
//    }
//    else if ([swipeRecogniser direction] == UISwipeGestureRecognizerDirectionRight)
//    {
//        self.pager.currentPage -=1;
//        
//        // Start
//        _picImageView.transform = CGAffineTransformMakeScale(1.5, 1.5);
//        _picImageView.alpha = 0;
//        [UIView animateKeyframesWithDuration:0.4 delay:0 options:0 animations:^{
//            // End
//            _picImageView.transform = CGAffineTransformMakeScale(1, 1);
//            _picImageView.alpha = 1;
//        } completion:^(BOOL finished) {
//        }];
//        
//    }
//    _picImageView.image = [UIImage imageNamed:
//                      [NSString stringWithFormat:@"ejemplo%ld",(long)self.pager.currentPage+1]];
//}
//
//
//
//
//- (IBAction)pager:(UIPageControl *)sender {
//    
//    _picImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"img%ld",sender.currentPage+1]];
//}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (IBAction)close:(id)sender {

    [self dismissViewControllerAnimated:YES completion:nil];
    
}
@end

