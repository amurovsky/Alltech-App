//
//  galeriasVC.h
//  Alltech
//
//  Created by Tejuino developers on 09/02/15.
//  Copyright (c) 2015 Tejuino developers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"

@interface galeriasVC : UIViewController <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UINavigationBar *galeriasNav;

@property (weak, nonatomic) IBOutlet UITableView *galeriasTable;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *rightMenu;

- (IBAction)returnButton:(id)sender;




@end








@interface slideShowVC : UIViewController <UIScrollViewDelegate,iCarouselDataSource, iCarouselDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *picImageView;


//- (IBAction)pager:(UIPageControl *)sender;

@property (weak, nonatomic) IBOutlet UIPageControl *pager;


@property (weak, nonatomic) IBOutlet UIButton *close;

- (IBAction)close:(id)sender;


@property (strong, nonatomic) IBOutlet iCarousel *customCarousel;

@property (weak, nonatomic) IBOutlet UILabel *descripcionFotosLabel;

@property (strong, nonatomic) IBOutlet UIScrollView *scroller;

@end